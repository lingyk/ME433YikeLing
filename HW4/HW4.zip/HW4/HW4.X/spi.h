#ifndef _SPI_H
#define _SPI_H

#define CS LATAbits.LATA0 
#define CONFIGA 0b01110000
#define CONFIGB 0b11110000

void init_SPI();
void DAC_write(char,short int);

#endif

