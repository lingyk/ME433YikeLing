#include "spi.h"       // constants, funcs for startup and UART
#include <xc.h> 	//for sine wave plotting

char SPI1_I0(char cmd){
    SPI1BUF = cmd;
    while(!SPI1STATbits.SPIRBF){;}
    return SPI1BUF;
}

void init_SPI(){
    SDI1Rbits.SDI1R = 0b0100;
    TRISAbits.TRISA1 = 0;               // Make RPA1 an output pin
    RPA1Rbits.RPA1R = 0b0011;           // Set RPA1 to SDO1 (pin 3 -> SDI pin 5 on DAC)
    TRISAbits.TRISA0 = 0;               // Set A0 as an output pin (CS)
    SS1Rbits.SS1R = 0b0000;             // Set RPA0 to SS1 (pin 2 -> CS pin 3 on DAC)
    CS = 1;
    SPI1CON = 0;
    SPI1BUF;
    SPI1BRG = 0x1;
    SPI1STATbits.SPIROV = 0;
    SPI1CONbits.CKE = 1;   
    SPI1CONbits.MSTEN = 1;
    SPI1CONbits.ON = 1;
    CS = 0;
    SPI1_I0(0x01);
    SPI1_I0(0x41);
    CS = 1;
}

void DAC_write(char config_bits,short int data){
    char first = data >>6;
    char bit1 = config_bits | first;
    char bit2 = data << 2;
    CS = 0;
    SPI1_I0(bit1);
    SPI1_I0(bit2);
    CS = 1;
}

